This script will slowly scrape truepeoplesearch and print results to console

Test Run:
```
npm install
node index.js
```

Save to file:
```
node index.js > test.txt
```